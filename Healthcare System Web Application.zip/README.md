
  # Healthcare System Web Application

  This is a code bundle for Healthcare System Web Application. The original project is available at https://www.figma.com/design/jVJZnBJa3AkMtsVAqznB6i/Healthcare-System-Web-Application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  